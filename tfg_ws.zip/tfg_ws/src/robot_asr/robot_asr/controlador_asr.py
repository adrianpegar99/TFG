#Importamos la librería del framework ROS2 en Python y el módulo que contiene
#la definición de los tipos de formato estándar en las comunicaciones de ROS2.
import rclpy 
from rclpy.node import Node
from std_msgs.msg import String

#Importamos la librería de procesamiento del lenguaje natural (NLP) spaCy:
import spacy

#Importamos el matcher para la detección de patrones.
from spacy.matcher import Matcher

#Importamos la librería de la API de la IA 
#generativa de lenguaje de Google ("Gemini")
import google.generativeai as genai

#Importamos el módulo "re" para realizar un
#pre-procesamiento de la respuesta obtenida del chatbot.
import re


#Utilizamos la librería de la API de texto a voz de Google 
#("Google Text-to-Speech",gTTS) para reproducir la respuesta del chatbot por voz:
from gtts import gTTS

#Importamos la librería playsound para reproducir ficheros de audio desde Python:
from playsound import playsound


class controlador_asr(Node):

    def __init__(self):
        super().__init__('controlador_asr')
        self.get_logger().info('Modo de control por reconocimiento de voz automático activo.')
        self.get_logger().info('Indique a algún robot que realice alguna acción o realice alguna consulta al chatbot inteligente.')
        
        #Creamos el objeto de suscripción al topic de la transcripción y los
        #objetos de publicación correspondientes para comandar a los robots.
        self.subs_transcripcion_ = self.create_subscription(String,'/topic_transcripcion',self.callback_command,10)
        self.pub_robot1_ = self.create_publisher(String,'/topic_cmd_robot1',10)
        self.pub_robot2_ = self.create_publisher(String,'/topic_cmd_robot2',10)
        self.pub_robot_manip_= self.create_publisher(String,'/topic_cmd_robot_manip',10)
        
        #Creamos un objeto de publicación de control para informar al nodo transcriptor cuando
        #se procese la orden/consulta y poder continuar con la grabación automática de voz por micrófono:
        self.pub_control_= self.create_publisher(String,'/topic_control',10)
        
        #Cargamos el modelo pipeline de spaCy en español:
        self.pln = spacy.load("es_dep_news_trf")

        #Inicializamos el matcher. 
        self.matcher = Matcher(self.pln.vocab)

        #Definimos patrón de búsqueda heurístico para generar comandos sobre los robots.
        patron = [{"POS":"VERB","OP":"?"},{"POS":"ADP","OP":"?"},{"POS":"DET","OP":"?"},
        {"TEXT":{"IN": ["robot","robots"]}},{"TEXT":{"IN": ["móvil","móviles","mobile","manipulador"]},"OP":"?"},           
        {"POS":"NUM","OP":"?"},{"TEXT":"uno","OP":"?"},{"POS":"VERB","OP":"?"},{"POS":"ADP","OP":"?"},{"POS":"DET","OP":"?"},
        {"POS":"NOUN","OP":"?"},{"POS":{"IN": ["ADP","DET"]},"OP":"+"},
        {"POS":"NOUN"},{"POS":{"IN": ["ADJ","NUM"]},"OP":"?"},{"TEXT":"uno","OP":"?"}]
        
        #Añadimos el patrón de búsqueda al matcher.
        self.matcher.add("patron_cmd",[patron])
        
        #Inicializamos el modelo generativo de texto de la IA de Google.
        self.model = genai.configure(api_key="AIzaSyAX6MYVWMnSZLsKvZdO8pamaEljyEePEtc")
        self.model = genai.GenerativeModel('gemini-pro')
        
        #Nombre del archivo donde se guardará el audio de la respuesta del chatbot:               
        self.file = "consulta.mp3"     
    
    #Función callback que se ejecutará cada vez 
    #que se reciba un mensaje del nodo transcriptor.
    def callback_command(self,msg):
        self.get_logger().info('Mensaje recibido: '+msg.data)  
        
        #Obtenemos el objeto resultante del procesamiento del 
        #lenguaje natural del mensaje transcrito de voz a texto con el modelo preentrenado de spaCy.
        doc = self.pln(msg.data)
           
        #Utilizamos el matcher sobre el objeto NLP
        #para la detección de patrones.
        matches = self.matcher(doc)
              
        #Si se ha detectado algún patrón, se generan los comandos correspondientes 
        #a partir de los patrones detectados una vez tokenizados.
        if len(matches)>0:
            resultado = [doc[start:end].text for match_id,start,end in matches]
            
            command = String()
            
            #Variable tipo lista para controlar que no se envíen comandos repetidos
            #a un mismo robot debido a diferentes patrones detectados:
            detect = [False,False,False,False]
            
            #Evaluamos cada uno de los patrones detectados para generar comandos.
            for pattern in resultado:
                #Tokenizamos el patrón detectado.
                pattern_token = pattern.split()
                find = False
            
                #En primer lugar, se identifica el punto al que deberá 
                #moverse o en el que cargará la pieza el robot correspondiente. 
                #Posteriormente,se identifica el/los robot/s a comandar.
                
                if pattern_token[len(pattern_token)-1] in ['inicial','1','uno']:
                    command.data = "1"
                    find = True
                elif pattern_token[len(pattern_token)-1] in ['final','2','dos']:    
                    command.data = "2"
                    find = True
                elif pattern_token[len(pattern_token)-1] in ['3','tres']:
                    command.data = "3"
                    find = True
                
                if find:    
                    for i in range(len(pattern_token)): 
                                
                        if pattern_token[i]== "manipulador" and detect[0]==False:
                            detect[0] = True
                            self.pub_robot_manip_.publish(command)
                            self.get_logger().info('Robot manipulador cargando en el punto '+command.data)
                            break
                            
                        elif pattern_token[i] in ["móvil","mobile","robot"]:
                                
                            if pattern_token[i+1] in ['1','uno'] and detect[1]==False:
                                detect[1] = True
                                self.pub_robot1_.publish(command)
                                self.get_logger().info('Robot móvil 1 yendo al punto '+command.data)
                                break
   
                            elif pattern_token[i+1] in ['2','dos'] and detect[2]==False:
                                detect[2] = True
                                self.pub_robot2_.publish(command)
                                self.get_logger().info('Robot móvil 2 yendo al punto '+command.data)
                                break
                            
                        elif pattern_token[i] in ["robots","móviles"] and detect[3]==False:                          
                                detect[3] = True
                                self.pub_robot1_.publish(command)
                                self.pub_robot2_.publish(command)
                                self.get_logger().info('Robots móviles yendo al punto '+command.data)
                                break
                                
        #Si no se detecta ningún patrón, se realizará una consulta 
        #al modelo generativo de texto de la IA de Google ("gemini")
        else:
            self.consulta_chatbot(msg.data)
            
        #Una vez procesado el comando o la consulta, enviamos un mensaje por el topic de control 
        #para continuar con la grabación automática por micrófono:
        control = String()
        control.data = "grabación"
        self.pub_control_.publish(control)

     
    def consulta_chatbot(self,msg):
        
        #En primer lugar, enviamos un mensaje por el topic de control al nodo transcriptor
        #para informar de que se está procesando la consulta al chatbot inteligente, 
        #manteniéndose el modo de grabación automática de voz desactivado.
        control = String()
        control.data = "consulta"
        self.pub_control_.publish(control)
        
        print("Realizando consulta al chatbot inteligente...")
        
        #Obtenemos la respuesta a la consulta a partir de la
        #API del modelo de IA generativo de Google:
        respuesta = self.model.generate_content(msg)
        respuesta = re.sub("[<>*]","",respuesta.text)
        print(respuesta)
        
        #Inicializamos el objeto de texto a voz con la respuesta del chatbot,
        #estableciendo como lenguaje español de España. Guardamos el audio en un fichero .mp3
        tts = gTTS(respuesta,lang ='es')
        tts.save("/home/robotics/"+self.file)
        
        #Reproducimos el fichero .mp3 generado por el motor TTS con la librería playsound:
        playsound("/home/robotics/"+self.file)
     

def main(args=None):
    #Inicializamos la librería de ROS2 y creamos una instancia u objeto
    #de la clase definida con anterioridad.
    rclpy.init(args=args)
    controlador = controlador_asr()
    
    rclpy.spin(controlador)
   
    controlador.destroy_node()
    rclpy.shutdown()

        
if __name__ == '__main__':
    main()
