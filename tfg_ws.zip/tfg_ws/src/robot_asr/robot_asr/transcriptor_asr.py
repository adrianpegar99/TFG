#Importamos la librería del framework ROS2 en Python y el módulo que contiene
#la definición de los tipos de formato estándar en las comunicaciones de ROS2.
import rclpy 
from rclpy.node import Node
from std_msgs.msg import String

import re

#Importamos la librería de la red neuronal 
#de reconocimiento automático del habla (ASR)
import whisper

#Importamos las librerías necesarias para la grabación de audio 
#a través del micrófono y el almacenamiento en un archivo .wav:
import pyaudio
import wave

#Importamos el módulo audioop, que realiza operaciones sobre 
#datos de audio sin procesar.
import audioop

class transcriptor_asr(Node):

    def __init__(self):
        super().__init__('transcriptor_asr')
        self.get_logger().info('Modo de transcripción de voz a texto automática activado.')
        #Establecemos modo por defecto del nodo (grabación automática con detección de voz):
        self.mode = 0
        
        #Creamos el objeto de publicación con el que se enviará la transcripción.
        self.pub_transcripcion_ = self.create_publisher(String,'/topic_transcripcion',10)
        
        #Creamos un objeto de suscripción de control para saber 
        #cuándo se debe continuar con la grabación por micrófono:
        self.subs_control_ = self.create_subscription(String,'/topic_control',self.callback_control,10)
        
        #Variable para controlar el envío de datos al nodo controlador.
        self.sent = False
        
        #Cargamos el modelo "tiny" de Whisper 
        self.model = whisper.load_model("tiny")
        
        #Definimos parámetros para la grabación de audio a través del micro:
        self.format = pyaudio.paInt16
        self.channels = 2
        self.rate = 44100
        self.chunk = 1024
        self.file = "grabacion.wav"
        
        #Creamos una instancia de la clase PyAudio de la librería pyaudio:
        self.audio = pyaudio.PyAudio()
             
    def callback_control(self,msg):
        
        if msg.data == "grabación":
            
            #Si llega el texto "grabación" por el topic de control ya se habrá procesado
            #el comando o la consulta correspondiente, por lo que volvemos al modo por defecto:    
            print("Modo de grabación automática activado")
            self.mode = 0
        
        elif msg.data == "consulta":
            
            #Si llega el texto "consulta" por el topic de control, se estará procesando 
            #una consulta al chatbot inteligente, por lo que detenemos el modo de grabación automática:    
            print("Modo consulta activado")
            self.mode = 1
            
    def grabar_audio(self):
        #Inicializamos la grabación del micrófono con los parámetros
        #definidos con anterioridad, haciendo uso de la librería pyaudio: 
        stream = self.audio.open(format=self.format,channels=self.channels,rate=self.rate,input=True,frames_per_buffer=self.chunk)
        
        #Definimos variables auxiliares para el proceso de grabación, estableciendo 
        #un umbral heurístico para la detección automática de voz:
        fin = False
        grabando = False
        umbral = 800
        
        while fin == False:
            
            #Inicializamos cada segundo una lista donde se almacenarán 
            #los valores RMS correspondientes a cada uno de los buffers de frames:
            rms_list = []
            
            #Leemos los chunks o buffers de frames (muestras de audio sin procesar
            #en formato PCM) durante 1 segundo:
            for i in range(0,int(self.rate/self.chunk)):
                
                data = stream.read(self.chunk)
                
                #Calculamos el valor cuadrático medio (RMS) de cada buffer de la
                #señal de audio sin procesar, el cual es una medida de potencia de la misma:
                rms = audioop.rms(data,2)
                
                #Almacenamos en una lista todos los valores RMS 
                #de la señal de audio sin procesar durante un segundo:
                rms_list.append(rms)
               
                #Si el valor RMS del chunk actual supera el umbral preestablecido
                #significa que se ha detectado un sonido considerable
                #(como puede ser una voz), por lo que se comienza a grabar:
                if rms>umbral and grabando == False:
                    print('Grabando...')
                    #Inicializamos la grabación, creando una lista
                    #donde se almacenarán los buffers de frames de audio sin procesar.
                    frames = []
                    grabando =  True
                elif grabando: 
                    #Almacenamos los datos correspondientes a la grabación 
                    #a partir de los buffers de frames del audio sin procesar:
                    frames.append(data)
            
            #Tras cada segundo de grabación, comprobamos el valor RMS máximo 
            #de la señal de audio sin procesar, para detectar cuando se deja
            #de hablar y así finalizar la grabación:
            if grabando:
                if max(rms_list)<umbral:
                    print('Grabación finalizada.')
                    fin = True
               
        #Detenemos grabación:
        stream.stop_stream()
        stream.close()
        
        #Almacenamos el archivo de audio en formato .wav
        #para realizar la transcripción a texto:
        wav = wave.open("/home/robotics/"+self.file,'wb')
        wav.setnchannels(self.channels)
        wav.setsampwidth(self.audio.get_sample_size(self.format))
        wav.setframerate(self.rate)
        wav.writeframes(b"".join(frames))
        wav.close()
        print("Grabación guardada")
        
    def transcript(self,audio):
        #Transcribimos a texto el audio grabado con el modelo de Whisper.
        result = self.model.transcribe(audio,fp16=False,language="Spanish")
        transcripcion = result["text"]
        self.get_logger().info("Transcripción realizada: "+transcripcion)
        
        #Eliminamos puntos, comas, signos de interrogación y signos de exclamación 
        #de la transcripción. Además, la pasamos a minúscula y la 
        #tokenizamos para identificar la palabra clave "hola".
        transcripcion = re.sub("[.,,,?,¿,!,¡]","",transcripcion).lower().split()
        self.sent = False
              
        for i in range(len(transcripcion)):
            #Si se detecta la palabra clave, se envía                                                     
            #por el topic de ROS2 el contenido posterior del mensaje.        
            if transcripcion[i] == "hola":
                self.sent = True
                transcript = String() 
                transcript.data = " ".join(transcripcion[i+1:len(transcripcion)])
                self.get_logger().info("Mensaje enviado al controlador: "+transcript.data)
                self.pub_transcripcion_.publish(transcript)
                break

def main(args=None):
    
    #Inicializamos la librería de ROS2 y creamos una instancia u objeto
    #de la clase definida con anterioridad.
    rclpy.init(args=args)
    transcriptor = transcriptor_asr()  
    
    while rclpy.ok():
    
        #Si el nodo se encuentra en el modo por defecto (grabación automática):
        if transcriptor.mode == 0:
            transcriptor.grabar_audio()
            transcriptor.transcript("/home/robotics/"+transcriptor.file)
        
        #Si se ha enviado la transcripción al nodo controlador, esperamos
        #que llegue por el topic de control el mensaje correspondiente
        #para continuar con la grabación de voz automática.
        if transcriptor.sent:
            rclpy.spin_once(transcriptor)      
    
    transcriptor.destroy_node()
    rclpy.shutdown()
     
if __name__ == '__main__':
    main()
